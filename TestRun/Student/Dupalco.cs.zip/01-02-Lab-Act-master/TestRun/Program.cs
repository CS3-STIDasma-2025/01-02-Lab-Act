﻿
class Program {

    static void Main(string[] args)
    {
        //Change the name to run your code
        const string name = "Ruiz";
        StudentSelector.RunSelectedStudent(name);
    }

}