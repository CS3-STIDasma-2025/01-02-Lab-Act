﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestRun.Student
{
    internal class Ruiz : Student
    {
        public override void Run()
        {
            Console.WriteLine("Running Ruiz's code...");
            
        }
   
    }
}
//THIS IS A TEMPLATE FILE 
